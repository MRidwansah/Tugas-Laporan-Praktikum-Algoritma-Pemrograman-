import math

def kuadrat(n):
    kuadrat = math.sqrt(n)
    return kuadrat
def faktorial(n):
    faktorial = math.factorial(n)
    return faktorial
def sin(n):
    sin = math.sin(n)
    return sin
def cos(n):
    cos = math.cos(n)
    return cos
def tan(n):
    tan = math.tan(n)
    return tan